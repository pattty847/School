module.exports = {
  semi: false,
  singleQuote: true,
  printWidth: 150,
  tabWidth: 2,
  useTabs: false
}
