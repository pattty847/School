export const APPLICATION_START_TIME = Date.now()
export const MASTER_DOMAIN = /aggr.trade$/.test(window.location.hostname)
export const MAX_BARS_PER_CHUNKS = 10000
export const GRID_COLS = 24
