var width, height;

width = prompt("Enter the width of the rectangle.")
height = prompt("Enter the height of the rectangle.")

var area = width * height
var perimeter = (2 * width) + (2 * height)
console.log("Reactangle Stats: " + "\n" + "Area: " + area + "\n" + "Perimeter: " + perimeter)
alert("Reactangle Stats: " + "\n" + "Area: " + area + "\n" + "Perimeter: " + perimeter)