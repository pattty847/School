Hello Proffessor, 

I have worked hard to get this to work and I hope it will work on your machine. Perhaps I 
can use the WebSockets as AJAX requests.

As for the WebSockets, I am sure, I can do this in a better way as I believe looping through
an array of these sockets, adding a listener, and spitting out the price on the screen is not 
the most efficient way. Anyway thanks for everything this year. :)